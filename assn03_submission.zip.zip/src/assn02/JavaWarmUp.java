package assn02;
import java.util.Scanner;

// Here is a starter code that you may optionally use for this assignment.
// TODO: You need to complete these sections


public class JavaWarmUp {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);


        String[] categoriesList = {"phone", "laptop", "smart_watch"};


        int n = s.nextInt();


        // MM/DD/YY, HH:MM, Name, Price, Quantity, Rating, Duration


        // create corresponding size arrays
        String dateT[] = new String[n];
        String timeT[] = new String[n];
        String categoryT[] = new String[n];
        double Assembling_fee[] = new double[n];
        int quantityT[] = new int[n];
        double Assembling_Time[] = new double[n];
        double Energy_and_Device_Cost[] = new double[n];


        // TODO: Fill in the above arrays with data entered from the console.
        // Your code starts here:
        ;
        for (int i = 0; i < n; i++) {
            dateT[i] = s.next();
            timeT[i] = s.next();
            categoryT[i] = s.next();
            Assembling_fee[i] = s.nextDouble();
            quantityT[i] = s.nextInt();
            Assembling_Time[i] = s.nextDouble();
            Energy_and_Device_Cost[i] = Double.parseDouble(s.nextLine());
        }
        // Your code ends here.


        // Find items with highest and lowest price per unit
        int highestItemIndex = getMaxPriceIndex(Assembling_fee);
        int lowestItemIndex = getMinPriceIndex(Assembling_fee);


        // TODO: Print items with highest and lowest price per unit.
        // Your code starts here:
        System.out.printf("%s\n%s\n%s\n%.2f\n",dateT[highestItemIndex], timeT[highestItemIndex], categoryT[highestItemIndex], Assembling_fee[highestItemIndex]);
        System.out.printf("%s\n%s\n%s\n%.2f\n",dateT[lowestItemIndex], timeT[lowestItemIndex], categoryT[lowestItemIndex], Assembling_fee[lowestItemIndex]);
        // Your code ends here.


        // Calculate the average price, rating and duration of sales by category.
        // Maintain following category-wise stats in Arrays
        int[] numOfCategoriesC = new int[categoriesList.length];// so numOfCategoriesC[0] = # of categories of type categoriesList[0]
        double[] totPriceC = new double[categoriesList.length]; // total price of each category = sum(price x qty)
        int[] totQuantityC = new int[categoriesList.length];    // total qty of each category = sum (qty)
        double[] totAssembling_TimeC = new double[categoriesList.length]; // total Rating of each category = sum(price x qty)
        double[] totEnergy_and_Device_CostC = new double[categoriesList.length]; // total Duration of each category = sum(price x qty)


        // TODO: Calculate & Print Category-wise Statistics
        // Your code starts here:
        for (int i = 0; i < numOfCategoriesC.length; i++) {
            totPriceC[i] = 0;
            totQuantityC[i] = 0;
            numOfCategoriesC[i] = 0;
            totAssembling_TimeC[i] = 0;
            totEnergy_and_Device_CostC[i] = 0;


            for (int j = 0; j < n; j++) {
                if (categoryT[j].equals(categoriesList[i])) {
                    numOfCategoriesC[i] += 1;
                    totQuantityC[i] += quantityT[j];
                    totPriceC[i] += (Assembling_fee[j] * quantityT[j]);
                    totAssembling_TimeC[i] += Assembling_Time[j];
                    totEnergy_and_Device_CostC[i] += Energy_and_Device_Cost[j] ;
                }
            }
            double averagePrice = (totPriceC[i]/totQuantityC[i]);
            int averageRating = totQuantityC[i];
            double averageDuration = ((totPriceC[i]) - ((totAssembling_TimeC[i]*16) + totEnergy_and_Device_CostC[i]))/totQuantityC[i];


            System.out.printf("%s\n%d\n%.2f\n%.2f\n", categoriesList[i], averageRating, averagePrice, averageDuration);


        }
        // Your code ends here.
    }


    // TODO: Find index of item with the highest price per unit.
    static int getMaxPriceIndex(double[] priceT){
        // Your code starts here:
        int maxIndex = 0;
        for (int i = 0; i < priceT.length; i++) {
            if (priceT[i] > priceT[maxIndex] ) {
                maxIndex = i;
            }
        }
        return(maxIndex); // modify this as well
        // Your code ends here.
    }


    // TODO: Find index of item with the lowest price per unit.
    static int getMinPriceIndex(double[] priceT){
        // Your code starts here:
        int minIndex = 0;
        for (int i = 0; i < priceT.length; i++) {
            if (priceT[i] < priceT[minIndex]) {
                minIndex = i;
            }
        }
        return(minIndex); // modify this as well
        // Your code ends here.
    }
}
