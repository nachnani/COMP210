package assn07;

import java.util.*;

public class PasswordManager<K,V> implements Map<K,V> {
    private static final String MASTER_PASSWORD = "ILoveBaseball";
    private Account[] _passwords;

    public PasswordManager() {
        _passwords = new Account[50];
    }


    // TODO: put
    @Override
    public void put(K key, V value) {

        int hash = Math.abs(key.hashCode());
        int size = _passwords.length;
        int index = Math.abs(hash % size);

        Account<K,V> newAccount = new Account<>(key,value);
        Account<K,V> currentAccount = _passwords[index];

        if (currentAccount == null) {
            _passwords[index] = newAccount;
        }
        else {
            while (currentAccount != null) {
                if (currentAccount.getWebsite().equals(key)) {
                    currentAccount.setPassword(value);

                    return;
                }

                if (currentAccount.getNext() == null) {
                    currentAccount.setNext(newAccount);

                    return;
                }

                currentAccount = currentAccount.getNext();
            }
        }
    }

    // TODO: get
    @Override
    public V get(K key) {

        int hash = Math.abs(key.hashCode());
        int size = _passwords.length;
        int index = Math.abs(hash % size);

        Account<K,V> currentAccount = _passwords[index];

        while (currentAccount != null){
            if (currentAccount.getWebsite().equals(key)) {

                return currentAccount.getPassword();
            }
            currentAccount = currentAccount.getNext();
        }

        return null;
    }

    // TODO: size
    @Override
    public int size() {
        int size = 0;

        for (int i = 0; i < _passwords.length; i++){
            if (_passwords[i] != null){
                size++;

                Account temp = _passwords[i].getNext();

                while(temp != null){
                    size++;
                    temp = temp.getNext();
                }
            }
        }
        return size;

    }

    // TODO: keySet
    @Override
    public Set<K> keySet() {

        Set<K> keys = new HashSet<>();
        for (Account<K,V> account : _passwords){
            Account<K,V> currentAccount = account;

            while (currentAccount != null){

                keys.add(currentAccount.getWebsite());
                currentAccount = currentAccount.getNext();
            }
        }

        return keys;
    }

    // TODO: remove
    @Override
    public V remove(K key) {

        int hash = Math.abs(key.hashCode());
        int size = _passwords.length;
        int index = Math.abs(hash % size);

        Account<K,V> currentAccount = _passwords[index];
        Account<K,V> previousAccount = null;

        while (currentAccount != null) {
            if (currentAccount.getWebsite().equals(key)) {
                if (previousAccount == null){

                    _passwords[index] = currentAccount.getNext();
                }
                else {
                    previousAccount.setNext(currentAccount.getNext());
                }

                return currentAccount.getPassword();
            }
            previousAccount = currentAccount;
            currentAccount = currentAccount.getNext();
        }
        return null;
    }

    // TODO: checkDuplicate
    @Override
    public List<K> checkDuplicate(V value) {

        List<K> websites = new ArrayList<>();

        for (Account<K,V> account : _passwords) {
            Account<K,V> currentAccount = account;

            while (currentAccount != null) {
                if (currentAccount.getPassword().equals(value)) {
                    websites.add(currentAccount.getWebsite());
                }
                currentAccount = currentAccount.getNext();
            }
        }
        return websites;
    }

    // TODO: checkMasterPassword
    @Override
    public boolean checkMasterPassword(String enteredPassword) {
        return MASTER_PASSWORD.equals(enteredPassword);
    }


    /*
    Generates random password of input length
     */
    @Override
    public String generateRandomPassword(int length) {
        int leftLimit = 48; // numeral '0'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = length;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }

    /*
    Used for testing, do not change
     */
    public Account[] getPasswords() {
        return _passwords;
    }
}
