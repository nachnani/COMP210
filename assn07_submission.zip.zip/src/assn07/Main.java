package assn07;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String,String> passwordManager = new PasswordManager<>();

        // your code below

        System.out.println("Enter Master Password");
        String master = scanner.nextLine();

        while (!passwordManager.checkMasterPassword(master)) {

            System.out.println("Enter Master Password");
            master = scanner.nextLine();
        }

        List<String> routes = new ArrayList<>();

        routes.add("New Password");
        routes.add("Get password");
        routes.add("Delete account");
        routes.add("Check duplicate password");
        routes.add("Get accounts");
        routes.add("Generate random password");
        routes.add("Exit");

        String route = scanner.nextLine();
        boolean active = true;

        while (active) {

            while (!routes.contains(route)) {
                System.out.println("Command not found");
                route = scanner.nextLine();
            }

            if (route.equals("New Password")){
                String website = scanner.nextLine();
                String password = scanner.nextLine();
                passwordManager.put(website,password);
                System.out.println("New password added");

                route = scanner.nextLine();
            }

            if (route.equals("Get password")) {
                String website = scanner.nextLine();
                String password = passwordManager.get(website);

                if (password != null){
                    System.out.println(password);
                }
                else {
                    System.out.println("Account does not exist");
                }
                route = scanner.nextLine();
            }

            if (route.equals("Check duplicate password")) {
                String password = scanner.nextLine();
                List<String> websites = passwordManager.checkDuplicate(password);

                if (websites.isEmpty()) {
                    System.out.println("No account uses that password");
                }
                else {
                    System.out.println("Websites using that password");

                    for (int i = 0; i < websites.size(); i++){
                        System.out.println(websites.get(i));
                    }
                }
                route = scanner.nextLine();
            }

            if (route.equals("Get accounts")) {
                System.out.println("Your accounts:");
                String[] websites = passwordManager.keySet().toArray(new String[passwordManager.keySet().size()]);

                for (int i = 0; i < websites.length; i++){
                    System.out.println(websites[i]);
                }

            }

            if (route.equals("Generate random passwords")) {
                int len = scanner.nextInt();
                System.out.println(passwordManager.generateRandomPassword(len));
                scanner.nextLine();
                route = scanner.nextLine();
            }

            if (route.equals("Exit")){
                active = false;
            }
        }

    }
}
