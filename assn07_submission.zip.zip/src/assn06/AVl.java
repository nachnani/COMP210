package assn06;

public class AVLTree<T extends Comparable<T>> implements SelfBalancingBST<T> {
    // Fields
    private T _value;
    private AVLTree<T> _left;
    private AVLTree<T> _right;
    private int _height;
    private int _size;

    public AVLTree() {
        _value = null;
        _left = null;
        _right = null;
        _height = -1;
        _size = 0;
    }


    public int balance(){
        return Math.abs(this._right._height - this._left._height);
    }

    public AVLTree<T> rotate() {

        AVLTree<T> balancedTree = this;

        if (balancedTree != null){

            int bf = this.balance();

            if (bf > 1) {
                if (_right._height > _left._height){

                    if(_right._left._height > _right._right._height) {
                        this._right = this._right.rotateRight();
                    }

                    balancedTree = balancedTrees.rotateLeft();
                }

                if (_left._height > _right._height){

                    if(_left._right._height > _left._left._height){
                        this._left = this._left.rotateLeft();
                    }

                    balancedTree = balancedTrees.rotateRight();
                }
            }
        }


        return BalancedTree;
    }

    private AVLTree<T> rotateLeft() {

        if (this.isEmpty()){
            return null;
        }

        else {
            AVLTree<T> X = this._right;
            this._right = X._left;
            X._left = this;

            this.adjustHeightSize();
            X.adjustHeightSize();

            return X;

            AVLTree<T> X = this;
            AVLTree<T> Y = X._right;
            AVLTree<T> Z = Y._left;
            Y._left = X;
            X._right = Z;

            X._height = 1 + Math.max(X._left._height, X._right._height);
            Y._height = 1 + Math.max(Y._left._height, Y._right._height);

            return Y;
        }
    }

    private AVLTree<T> rotateRight() {
        if (this.isEmpty()){
            return null;
        }

        else {
            AVLTree<T> X = this._left;
            this._left = X._right;
            X._right = this;


            this.adjustHeightSize();
            X.adjustHeightSize();
            return X;

            AVLTree<T> X = this;
            AVLTree<T> Y = X._left;
            AVLTree<T> Z = Y._right;
            Y._right = X;
            X._left = Z;

            X._height = 1 + Math.max(X._left._height, X._right._height);
            Y._height = 1 + Math.max(Y._left._height, Y._right._height);

            return Y;
        }

    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public int height() {
        return _height;
    }

    @Override
    public int size() {
        return _size;
    }

    public void adjustHeightSize(){
            this._height = 1 + Math.max(_left._height, _right._height);
            this._size = 1 + _left._size + _right._size;
        }erride

    public SelfBalancingBST<T> insert(T element){
            if (isEmpty()) {

                _value = element;
                _left = new AVLTree<T>();
                _right = new AVLTree<T>();
                adjustHeightSize();

                return this;
            }
            AVLTree<T> fresh;

            if (element.compareTo(this._value) > 0) {
                this._right = (AVLTree<T>) this._right.insert(element);
            } else {
                this._left = (AVLTree<T>) this._left.insert(element);
            }

            fresh = this;
            fresh.adjustHeightSize();
            fresh = fresh.rotate();


            return fresh;

        }

    }

    @Override
    public SelfBalancingBST<T> remove(T element) {
        // TODO

        return null;
    }

    @Override
    public T findMin() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        if (_left.isEmpty()) {
            return _value;
        } else {
            return _left.findMin();
        }
    }

    @Override
    public T findMax() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        if (_right.isEmpty()) {
            return _value;
        } else {
            return _right.findMax();
        }
    }

    @Override
    public boolean contains(T element) {
        // TODO

        return false;
    }

    @Override
    public T getValue() {
        return _value;
    }

    @Override
    public SelfBalancingBST<T> getLeft() {
        if (isEmpty()) {
            return null;
        }
        return _left;
    }

    @Override
    public SelfBalancingBST<T> getRight() {
        if (isEmpty()) {
            return null;
        }
        return _right;
    }

}
