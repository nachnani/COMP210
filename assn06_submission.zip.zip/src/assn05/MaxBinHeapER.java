package assn05;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MaxBinHeapER  <V, P extends Comparable<P>> implements BinaryHeap<V, P> {

    private List<Prioritized<V,P>> _heap;
    /**
     * Constructor that creates an empty heap of hospital.Prioritized objects.
     */
    public MaxBinHeapER() {
        _heap = new ArrayList<>();
    }

    /**
     * Constructor that builds a heap given an initial array of hospital.Prioritized objects.
     */
    // TODO (Part 3): overloaded constructor
    public MaxBinHeapER(Prioritized<V, P>[] initialEntries ) {
        _heap = new ArrayList<>();

        for (Prioritized<V, P> entry : initialEntries) {
            enqueue(entry.getValue(), entry.getPriority());
        }
    }

    @Override
    public int size() {
        return _heap.size();
    }

    // TODO: enqueue
    @Override
    public void enqueue(V value, P priority) {
        Patient newPatient = new Patient(value, priority);

        _heap.add(newPatient);
        int index = _heap.size() - 1;

        while (index > 0) {
            int parentIndex = (index - 1) / 2;

            if (_heap.get(index).getPriority().compareTo(_heap.get(parentIndex).getPriority()) > 0) {
                Prioritized<V, P> temp = _heap.get(parentIndex);
                _heap.set(parentIndex, _heap.get(index));
                _heap.set(index, temp);
                index = parentIndex;
            }
            else {
                break;
            }
        }
    }

    // TODO: enqueue
    public void enqueue(V value) {
        Patient newPatient = new Patient(value);

        _heap.add(newPatient);
        int index = _heap.size() - 1;

        while (index > 0) {

            int parentIndex = (index - 1) / 2;

            if (_heap.get(index).getPriority().compareTo(_heap.get(parentIndex).getPriority()) > 0) {
                Prioritized<V, P> temp = _heap.get(parentIndex);
                _heap.set(parentIndex, _heap.get(index));
                _heap.set(index, temp);
                index = parentIndex;
            }
            else {
                break;
            }
        }
    }

    // TODO: dequeue
    @Override
    public V dequeue() {

        if (_heap.isEmpty()) {
            return null;
        }
        if (_heap.size() == 1) {
            return _heap.remove(0).getValue();
        }

        Prioritized<V, P> last = _heap.get(_heap.size() - 1);
        V max = _heap.get(0).getValue();

        _heap.set(0, last);
        _heap.remove(_heap.size() - 1);

        int index = 0;

        while (true) {

            int leftIndex = 2 * index + 1;

            if (leftIndex >= _heap.size()) {
                break;
            }

            int rightIndex = leftIndex + 1;
            int swapIndex = leftIndex;

            if (rightIndex < _heap.size() && _heap.get(leftIndex).getPriority().compareTo(_heap.get(rightIndex).getPriority()) < 0) {
                swapIndex = rightIndex;
            }

            if (_heap.get(index).getPriority().compareTo(_heap.get(swapIndex).getPriority()) < 0) {
                Prioritized<V, P> temp = _heap.get(index);
                _heap.set(index, _heap.get(swapIndex));
                _heap.set(swapIndex, temp);
                index = swapIndex;
            } else {
                break;
            }
        }

        return max;
    }

    // TODO: getMax
    @Override
    public V getMax() {
        if (_heap.isEmpty()) {
            return null;
        }

        return _heap.get(0).getValue();
    }

    @Override
    public Prioritized<V, P>[] getAsArray() {
        Prioritized<V,P>[] result = (Prioritized<V, P>[]) Array.newInstance(Prioritized.class, size());
        return _heap.toArray(result);
    }






}
